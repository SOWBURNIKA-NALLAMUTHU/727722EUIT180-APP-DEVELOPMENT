package com.example.petsback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetsbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetsbackApplication.class, args);
	}

}
