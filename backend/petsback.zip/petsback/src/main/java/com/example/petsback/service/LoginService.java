package com.example.petsback.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.petsback.model.Login;
import com.example.petsback.repository.LoginRepository;

import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private LoginRepository loginRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public void registerUser(Login login) {
        login.setPassword(bCryptPasswordEncoder.encode(login.getPassword()));
        loginRepository.save(login);
    }

    public Optional<Login> loginUser(String email, String password) {
        Optional<Login> user = loginRepository.findByEmail(email);
        if (user.isPresent() && bCryptPasswordEncoder.matches(password, user.get().getPassword())) {
            return user;
        }
        return Optional.empty();
    }
}
